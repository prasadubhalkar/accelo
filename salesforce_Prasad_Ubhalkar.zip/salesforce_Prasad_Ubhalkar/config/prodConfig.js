const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const commonConfig = require('./commonConfig');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const GLOBALS = {
    ENV: "production",
    BLOG_API_URL: "/Blog/api/",
    NODE_ENV: "production"
};
module.exports = function() {
    return webpackMerge(commonConfig(GLOBALS.ENV), {
        devtool: 'source-map',
        entry: {
            main: path.resolve(__dirname, '../src/index')
        },
        target: 'web',
        output: {
            path: path.resolve(__dirname, '../dist'), // Note: Physical files are only output by the production build task `npm run build`.
            publicPath: '',
            filename: 'index.js',
        },
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, '../src/index.html'),
                title: "Sales Force Assignment"
            }),
            new webpack.optimize.OccurrenceOrderPlugin(),
            new webpack.DefinePlugin({
                'process.env': {
                    'ENV': JSON.stringify(GLOBALS.ENV),
                    'BLOG_API_URL': JSON.stringify(GLOBALS.BLOG_API_URL),
                    'NODE_ENV': JSON.stringify(GLOBALS.NODE_ENV)
                }
            }),
            new webpack.optimize.UglifyJsPlugin()
        ]
    });
};
