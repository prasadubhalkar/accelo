const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const commonConfig = require('./commonConfig');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const GLOBALS = {
    ENV: "development",
    BLOG_API_URL: "http://localhost:8080/Blog/api/",
    NODE_ENV: "development"
};
module.exports = function() {
    return webpackMerge(commonConfig(GLOBALS.ENV), {
        devtool: 'inline-source-map',
        entry: path.resolve(__dirname, '../src/index'),
        target: 'web',
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, '../src/index.html'),
                title: "SalesForce Assignment"
            }),
            new webpack.HotModuleReplacementPlugin(),
            new webpack.DefinePlugin({
                'process.env': {
                    'ENV': JSON.stringify(GLOBALS.ENV),
                    'BLOG_API_URL': JSON.stringify(GLOBALS.BLOG_API_URL),
                    'NODE_ENV': JSON.stringify(GLOBALS.NODE_ENV)
                }
            })
        ],
        devServer: {
            contentBase: path.resolve(__dirname, '../src'),
            port: 3000,
            host: "localhost",
            historyApiFallback: true,
            watchOptions: {
                aggregateTimeout: 300,
                poll: 1000
            }
        }
    });
};