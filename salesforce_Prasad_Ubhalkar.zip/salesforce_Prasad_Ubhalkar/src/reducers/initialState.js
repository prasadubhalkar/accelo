export default {
    blogs: {
        list: null,
        newPost: null
    },
    http: {
        ajaxCallInProgress: false,
        errorMessage: null
    }
};