import {combineReducers} from 'redux';
import blogs from './blogsListReducer';
import httpStatus from './httpRequestReducer';

const rootReducer = combineReducers({
    blogs,
    httpStatus
});

export default rootReducer;