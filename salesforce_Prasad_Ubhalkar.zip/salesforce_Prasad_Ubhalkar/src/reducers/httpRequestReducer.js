import * as types from '../actions/actionTypes';
import initialState from './initialState';

export default function httpRequest(state = initialState.http, action) {
    switch (action.type) {
        case types.BEGIN_XHR_CALL:
            return Object.assign({}, state, {
                ajaxCallInProgress: true
            });
        case types.ERROR_XHR_CALL:
            return Object.assign({}, state, {
                ajaxCallInProgress: false,
                errorMessage: action.error
            });
        case types.END_XHR_CALL:
            return Object.assign({}, state, {
                ajaxCallInProgress: false
            });
        default:
            return state;
    }
}