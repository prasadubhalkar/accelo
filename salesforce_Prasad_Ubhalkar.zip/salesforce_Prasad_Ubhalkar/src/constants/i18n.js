const i18n = {
    header: {
        heading: "Blogger's Blog"
    },
    newPost: {
        postTitleLabel: "Post Title",
        postTitlePlaceHolder: "Enter Post Title",
        postContentLabel: "Post Content",
        postContentPlaceholder: "Enter Post Content",
        newPostButton: "Create"
    },
    postEdit: {
        postEditTitleLabel: "Post Title",
        postEditContentLabel: "Post Content",
        postEditButtonLabel: "Update"
    },
    postsList: {
        postsListLabelDeleteAll: "Delete All",
        postsListLabelAddNew: "(+ Add)",
        postsListNoListFound: "No posts found",
        postsListTitle: "Posts"
    },
    post: {
        editLabel: "Edit",
        deleteLabel: "Delete"
    }
};
export default i18n;
