import * as types from './actionTypes';
import BlogService from '../services/BlogsService';
import {beginXhrCall, errorXhrCall, endXhrCall} from './httpRequestActions';

export function loadBlogsList(blogsList) { return { type: types.LOAD_BLOGS, blogsList }; }

/**
 * Load the list of blogs from the backend,
 * Calling the RESTful API
 * @returns {Function}
 */
export function loadBlogs() {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return loadBlogPosts(dispatch);
    };
}

/**
 * Call the API to create the new post
 * @param title
 * @param text content for the post
 * @returns {Function}
 */
export function createNewPost(title, text) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return BlogService.insertNewPost(title, text).then(response => {
            if(response.ok) {
                dispatch(endXhrCall());
                setTimeout(loadBlogPosts(dispatch));
            }
            else {
                dispatch(endXhrCall());
                dispatch(errorXhrCall("Failed to add new post"));
            }
        }).catch(error => {
            dispatch(endXhrCall());
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

/**
 * Will call the backend API to trigger post update
 * @param postId
 * @param title updated title of the post
 * @param text updated content of the post
 * @returns {Function}
 */
export function updatePost(postId, title, text) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return BlogService.updatePost(postId, title, text).then(response => {
            if(response.ok) {
                dispatch(endXhrCall());
                setTimeout(loadBlogPosts(dispatch));
            }
            else {
                dispatch(endXhrCall());
                dispatch(errorXhrCall("Failed to update existing post"));
            }
        }).catch(error => {
            dispatch(endXhrCall());
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

/**
 * Will call the API to delete a single Post
 * @param postId
 * @returns {Function}
 */
export function deletePost(postId) {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return BlogService.deletePost(postId).then(response => {
            if(response.ok) {
                dispatch(endXhrCall());
                setTimeout(loadBlogPosts(dispatch));
            }
            else {
                dispatch(endXhrCall());
                dispatch(errorXhrCall("Failed to delete post"));
            }
        }).catch(error => {
            dispatch(endXhrCall());
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

/**
 * Will trigger backend API to delete all the posts
 * @returns {Function}
 */
export function deleteAllPost() {
    return function(dispatch) {
        dispatch(beginXhrCall());
        return BlogService.deleteAll().then(response => {
            if(response.ok) {
                dispatch(endXhrCall());
                setTimeout(loadBlogPosts(dispatch));
            }
            else {
                dispatch(endXhrCall());
                dispatch(errorXhrCall("Failed to delete all posts"));
            }
        }).catch(error => {
            dispatch(endXhrCall());
            dispatch(errorXhrCall(error));
            throw(error);
        });
    };
}

/**
 * Load the posts list
 * @param dispatch
 */
export function loadBlogPosts(dispatch) {
    BlogService.getPosts().then(response => {
        if(response.ok) {
            response.json().then(json => {
                dispatch(endXhrCall());
                dispatch(loadBlogsList(normalizeBlog(json.blog.posts)));
            });
        }
        else {
            response.json().then(json => {
                dispatch(endXhrCall());
                dispatch(errorXhrCall(json.message));
            });
        }
    }).catch(error => {
        dispatch(endXhrCall());
        dispatch(errorXhrCall(error));
        throw(error);
    });
}

/**
 * Normalize the blog posts
 * @param blogPosts
 * @returns {{list: Array}}
 */
export function normalizeBlog(blogPosts) {
    let blogs = {
        list: []
    };
    blogPosts.map((blog) => {
        blogs[blog.id] = blog;
        blogs.list.push({
            id: blog.id,
            title: blog.title
        });
    });
    return blogs;
}