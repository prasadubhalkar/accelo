/* Ajax Status */
export const BEGIN_XHR_CALL = 'BEGIN_XHR_CALL';
export const ERROR_XHR_CALL = 'ERROR_XHR_CALL';
export const END_XHR_CALL = 'END_XHR_CALL';

/* Get Blogs */
export const LOAD_BLOGS = "LOAD_BLOGS";



