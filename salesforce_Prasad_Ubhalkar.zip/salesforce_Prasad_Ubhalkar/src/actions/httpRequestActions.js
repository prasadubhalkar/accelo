import * as types from './actionTypes';

export function beginXhrCall() { return { type: types.BEGIN_XHR_CALL }; }

export function errorXhrCall(error) { return { type: types.ERROR_XHR_CALL, error }; }

export function endXhrCall() { return { type: types.END_XHR_CALL }; }
