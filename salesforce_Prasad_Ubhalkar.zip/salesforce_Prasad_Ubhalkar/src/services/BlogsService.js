/**
 * Class will make the API calls to the backend Server
 * All functions will return Promise
 */
class BlogsService {
    /**
     * Will get all the posts
     * @returns {*}
     */
    static getPosts() {
        return fetch(
            process.env.BLOG_API_URL,
            {
                method: "GET",
                headers: {
                    Accept: "application/json"
                }
            }
        );
    }

    /**
     * Will insert a new post
     * @param title
     * @param text
     * @returns {*}
     */
    static insertNewPost(title, text) {
        return fetch(
            process.env.BLOG_API_URL,
            {
                method: "POST",
                headers: {
                    "Accept": "application/x-www-form-urlencoded",
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "title="+title+"&"+"text="+text
            }
        );
    }

    /**
     * Will update and existing post
     * @param postId
     * @param title
     * @param text
     * @returns {*}
     */
    static updatePost(postId, title, text) {
        return fetch(
            process.env.BLOG_API_URL + postId,
            {
                method: "POST",
                headers: {
                    "Accept": "application/x-www-form-urlencoded",
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "title="+title+"&"+"text="+text
            }
        );
    }

    /**
     * Will delete an existing post
     * @param postId
     * @returns {*}
     */
    static deletePost(postId) {
        return fetch(
            process.env.BLOG_API_URL + postId, { method: "DELETE" }
        );
    }

    /**
     * Will delete all posts
     * @returns {*}
     */
    static deleteAll() {
        return fetch(
            process.env.BLOG_API_URL, { method: "DELETE" }
        );
    }
}

export default BlogsService;
