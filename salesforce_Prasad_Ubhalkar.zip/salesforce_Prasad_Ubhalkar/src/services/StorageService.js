/**
 * Session Storage Service
 */
class SessionStorage {
    static checkItem(itemKey) {
        return (sessionStorage.getItem(itemKey) !== null);
    }

    static getItem(itemKey) {
        return sessionStorage.getItem(itemKey);
    }

    static setItem(itemKey, value) {
        sessionStorage.setItem(itemKey, value);
    }
}

export default SessionStorage;