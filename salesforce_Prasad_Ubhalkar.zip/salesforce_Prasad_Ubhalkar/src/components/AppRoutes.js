import React from 'react';
import { BrowserRouter, Route, Link } from 'react-router-dom';
import MainPage from './Posts';


class AppRoutes extends React.Component {
    render() {
        return (
            <BrowserRouter>
                <div className="page-container">
                    <div>
                        <Route exact path="/" component={MainPage}/>
                    </div>
                </div>
            </BrowserRouter>
        );
    }
}

export default AppRoutes;
