import React from 'react';
import PropTypes from 'prop-types';
import './index.scss';

/**
 * Will Provide a Read Only View
 * for a particular Post
 */
class PostView extends React.Component {
    /**
     * Create a initial state for the component
     */
    constructor() {
        super();
        this.state = {
            paragraphs: []
        };
    }

    /**
     * Will split the text based on the new line
     * characters and convert it in paragraphs
     */
    componentWillMount() {
        this.setState({
            paragraphs: this.props.text.split(/\r\n/)
        });
    }

    /**
     * Same logic to split in paragraphs, for the updates
     * @param nextProps
     */
    componentWillReceiveProps(nextProps) {
        this.setState({
            paragraphs: nextProps.text.split(/\r\n/)
        });
    }

    /**
     * Will Render the read only view for the component
     */
    render() {
        let paragraphs = this.state.paragraphs;
        return <section className="post-view">
            {
                paragraphs.map((paragraph, index) => {
                    return <p key={index}> {paragraph} </p>;
                })
            }
        </section>;
    }
}

/**
 * Prop types required for PostView
 */
PostView.propTypes = {
    text: PropTypes.string.isRequired
};
export default PostView;