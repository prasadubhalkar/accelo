import React from 'react';
import i18n from '../../constants/i18n';

/**
 * Functional Dumb component to render header
 */
const Header = () => {
    return <header>
        <h1>{i18n.header.heading}</h1>
    </header>;
};

export default Header;
