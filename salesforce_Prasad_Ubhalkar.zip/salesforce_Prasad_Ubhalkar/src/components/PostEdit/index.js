import React from 'react';
import PropTypes from 'prop-types';
import i18n from '../../constants/i18n';
import './index.scss';

/**
 * Post Edit Component will allow
 * us to edit an existing post
 */
class PostEdit extends React.Component {
    /**
     * Constructor
     * Bind the update post method to class context
     */
    constructor() {
        super();
        this.updatePost = this.updatePost.bind(this);
    }

    /**
     * Will call the parent and send the update post context
     * @param postId existing Post Id
     * @param title existing post edited / original title
     * @param text existing post edited / original text
     */
    updatePost(postId, title, text) {
        this.props.updatePost(postId, title, text);
    }

    /**
     * Render the component under parent DOM Node
     */
    render() {
        let paragraphs = this.props.text;
        let title = this.props.title;
        let self = this;
        return <section className="post-edit">
            <form>
                <div className="form-group">
                    <label htmlFor="updatedPostTitle" aria-label={i18n.postEdit.postEditTitleLabel}>
                        {i18n.postEdit.postEditTitleLabel}
                    </label>
                    <input id="updatedPostTitle"
                           className="form-control"
                           ref={"updatedPostTitle"}
                           tabIndex={1}
                           type="text" defaultValue={title}/>
                </div>
                <div className="form-group">
                    <label htmlFor="updatedPostContent" aria-label={i18n.postEdit.postEditContentLabel}>
                        {i18n.postEdit.postEditContentLabel}
                    </label>
                    <textarea className="form-control"
                              id="updatedPostContent"
                              ref={"updatedPostText"}
                              tabIndex={2}
                              defaultValue={paragraphs}/>
                </div>
                <button className="btn btn-primary"
                        tabIndex={3}
                        aria-label={i18n.postEdit.postEditButtonLabel}
                        onClick={function(event){
                            event.preventDefault();
                            self.updatePost(
                                self.props.postId,
                                self.refs.updatedPostTitle.value,
                                self.refs.updatedPostText.value
                            );
                        }}>{i18n.postEdit.postEditButtonLabel}
                </button>
            </form>
        </section>;
    }
}

/**
 * Required Props and Types for Post Edit Component
 */
PostEdit.propTypes = {
    postId: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    text: PropTypes.string.isRequired,
    updatePost: PropTypes.func.isRequired
};

export default PostEdit;