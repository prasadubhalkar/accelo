// This component handles the App template used on every page.
import React from 'react';
import PropTypes from 'prop-types';
import AppRoutes from './AppRoutes';
import {connect} from 'react-redux';
import * as httpRequests from '../actions/httpRequestActions';
import {bindActionCreators} from 'redux';
import Header from './Header';

class App extends React.Component {
    render() {
        let ajaxInProgress = this.props.ajaxCallInProgress;
        let errorMessage = this.props.errorMessage;
        return (
            <div className="container-fluid">
                <Header/>
                    {(ajaxInProgress) && <span className={"label label-warning"}> Loading... </span>}
                    {(errorMessage) && <span className={"label label-danger"}> {errorMessage} </span>}
                <AppRoutes/>
            </div>
        );
    }
}

App.propTypes = {
    ajaxCallInProgress: PropTypes.bool,
    errorMessage: PropTypes.string
};
function mapStateToProps(state) {
    return {
        ajaxCallInProgress: state.httpStatus.ajaxCallInProgress,
        errorMessage: state.httpStatus.errorMessage
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(httpRequests, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps) (App);
