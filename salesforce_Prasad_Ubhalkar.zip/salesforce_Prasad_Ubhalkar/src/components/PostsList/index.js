import React from 'react';
import PropTypes from 'prop-types';
import i18n from '../../constants/i18n';
import './index.scss';

/**
 * This is the side component to show
 * the list of posts
 */
class PostsList extends React.Component{
    /**
     * Bind the component methods
     */
    constructor() {
        super();
        this.state = {
            selectedId : null
        };
        this.setSelectedBlog = this.setSelectedBlog.bind(this);
        this.triggerShowCreatePost = this.triggerShowCreatePost.bind(this);
        this.triggerDeleteAllPosts = this.triggerDeleteAllPosts.bind(this);
        this.blogLinkClasses = "blog-item-link list-group-item";
    }

    /**
     * If nothing is selected on load,
     * select the first post by default
     */
    componentWillMount() {
        if(this.props.posts && this.props.posts.length) {
            this.setState({
                selectedId: this.props.posts[0].id
            });
        }
    }

    /**
     * If nothing is selected or list is edited
     * after delete and update, select 0 by default
     * @param nextProps
     */
    componentWillReceiveProps(nextProps) {
        if(nextProps.posts && nextProps.posts.length) {
            if(!this.state.selectedId) {
                this.setState({
                    selectedId: nextProps.posts[0].id
                });
            } else if(nextProps.posts[0].id !== this.state.selectedId) {
                this.setState({
                    selectedId: nextProps.posts[0].id
                });
            }
        }
    }

    /**
     * When list item is clicked
     * trigger parent function
     * @param id postId
     */
    setSelectedBlog(id) {
        this.setState({
            selectedId: id
        });
        this.props.showBlog(id);
    }

    /**
     * When Add new post is clicked
     * this function is triggered
     */
    triggerShowCreatePost() {
        this.setState({
            selectedId: null
        });
        this.props.showCreateView();
    }

    /**
     * When Delete All is clicked from
     * the menu trigger this function
     */
    triggerDeleteAllPosts() {
        this.setState({
            selectedId: null
        });
        this.props.clearAllPosts();
    }

    /**
     * Render the Aside component with Navigation
     * to the posts that are loaded
     */
    render() {
        let self = this;
        let selectedId = this.state.selectedId;
        return (
            <div className="panel panel-info list-of-posts">
                <div className="panel-heading">
                    <b> {i18n.postsList.postsListTitle} </b>
                    <a onClick={this.triggerDeleteAllPosts} tabIndex={1} aria-label={i18n.postsList.postsListLabelDeleteAll}>
                        {i18n.postsList.postsListLabelDeleteAll}
                    </a>
                    <a onClick={this.triggerShowCreatePost} tabIndex={2} aria-label={i18n.postsList.postsListLabelAddNew}>
                        {i18n.postsList.postsListLabelAddNew}
                    </a>
                </div>
                <div className="panel-body">
                    {!this.props.posts.length && <span>{i18n.postsList.postsListNoListFound}</span>}
                    <nav className="list-group">
                        {this.props.posts.map((post, index) => {
                            return <a key={index}
                                      className={(selectedId === post.id) ? this.blogLinkClasses + " active": this.blogLinkClasses}
                                      tabIndex={index}
                                      onClick={function(event) {
                                          event.preventDefault();
                                          self.setSelectedBlog(post.id);
                                      }}
                            > {post.title} </a>;
                        })}
                    </nav>
                </div>
            </div>
        );
    }
}

/**
 * Props Required by the Posts List component
 */
PostsList.propTypes = {
    posts: PropTypes.array.isRequired,
    showBlog: PropTypes.func.isRequired,
    showCreateView: PropTypes.func.isRequired,
    clearAllPosts: PropTypes.func.isRequired
};
export default PostsList;
