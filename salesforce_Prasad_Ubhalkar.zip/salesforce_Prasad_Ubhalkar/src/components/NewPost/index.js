import React from 'react';
import PropTypes from 'prop-types';
import i18n from '../../constants/i18n';
import './index.scss';

/**
 * Create New Post Component
 */
class NewPost extends React.Component{
    constructor() {
        super();
    }

    /**
     * Will Create the Form for creating
     * new posts
     */
    render() {
        let self = this;
        return <section className="post-edit">
            <form>
                <div className="form-group">
                    <label htmlFor="postTitle" aria-label={i18n.newPost.postTitleLabel}>
                        {i18n.newPost.postTitleLabel}
                    </label>
                    <input id="postTitle"
                           className="form-control"
                           ref={"newPostTitle"}
                           type="text"
                           tabIndex={1}
                           placeholder={i18n.newPost.postTitlePlaceHolder}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="postContent" aria-label={i18n.newPost.postContentLabel}>
                        {i18n.newPost.postContentLabel}
                    </label>
                    <textarea className="form-control"
                              id="postContent"
                              ref={"newPostContent"}
                              defaultValue=""
                              tabIndex={2}
                              placeholder={i18n.newPost.postContentPlaceholder}
                    />
                </div>
                <button className="btn btn-primary"
                        tabIndex={3}
                        aria-label={i18n.newPost.newPostButton}
                        onClick={function(event){
                            event.preventDefault();
                            self.props.createNewPost(
                                self.refs.newPostTitle.value,
                                self.refs.newPostContent.value
                            );
                        }}>{i18n.newPost.newPostButton}
                </button>
            </form>
        </section>;
    }
}

/**
 * Required Props for New Post
 */
NewPost.propTypes = {
    createNewPost: PropTypes.func.isRequired
};
export default NewPost;