import React from 'react';
import PropTypes from 'prop-types';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
/*import actions*/
import * as httpStatus from '../../actions/httpRequestActions';
import * as gitUsersAction from '../../actions/blogsListActions';
/*import child components*/
import PostsList from '../PostsList';
import PostView from '../PostView';
import PostEdit from '../PostEdit';
import NewPost from '../NewPost';
import i18n from '../../constants/i18n';
/*import styles*/
import './index.scss';

/**
 * Base / Main Page for Blog Application
 * Bind Methods, which take action on
 * behalf of child components
 */
class HomePage extends React.Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            postId: null,
            editMode: false,
            createMode: false
        };
        //will trigger the show and render selected post / blog by id
        this.showBlog = this.showBlog.bind(this);

        //will enable the edit mode for the given blog
        this.enableEditMode = this.enableEditMode.bind(this);

        //will show the form to create a new blog
        this.showCreateView = this.showCreateView.bind(this);

        //will handle the call to create a new post / blog entry in backend
        this.createNewPost = this.createNewPost.bind(this);

        //will delete the blog from the backend
        this.deletePost = this.deletePost.bind(this);

        //will delete all the posts from the backend
        this.clearAllPosts = this.clearAllPosts.bind(this);

        //will update the given post in the backend
        this.updatePost = this.updatePost.bind(this);
    }

    /**
     * Make a call initially to load all
     * the blogs from the backend
     */
    componentDidMount() {
        this.props.actions.loadBlogs();
    }

    /**
     * Will check for the Prop changes
     * if state does not have selected post id (null) => initial load select 0 index
     * if state changed and selected post id does not exists => select 0 by default
     * @param nextProps
     */
    componentWillReceiveProps(nextProps) {
        if(nextProps.posts && nextProps.posts.list.length) {
            if(!this.state.postId) {
                this.setState({
                    postId: nextProps.posts.list[0].id
                });
            }
            else if(nextProps.posts.list[0].id !== this.state.postId) {
                this.setState({
                    postId: nextProps.posts.list[0].id
                });
            }
        }
    }

    /**
     * Show selected blog contents
     * @param id
     */
    showBlog(id) {
        this.setState({
            postId: id,
            createMode: false,
            editMode: false
        });
    }

    /**
     * Will enable edit mode
     * for the selected post
     */
    enableEditMode() {
        this.setState({
            editMode: !this.state.editMode,
            createMode: false
        });
    }

    /**
     * Will enable create new
     * post View, show Textarea and title (NewPost)
     */
    showCreateView() {
        this.setState({
            createMode: !this.state.createMode,
            editMode: false
        });
    }

    /**
     * Will make and API Call to create a new
     * Post
     * @param title for the post
     * @param text content for the post
     */
    createNewPost(title, text) {
        this.props.actions.createNewPost(title, text);
        this.setState({
            createMode: false,
            editMode: false
        });
    }

    /**
     * Will delete the post, by calling Backend API
     */
    deletePost() {
        this.props.actions.deletePost(this.state.postId);
    }

    /**
     * Will Call backend API to delete all the existing posts
     */
    clearAllPosts() {
        this.props.actions.deleteAllPost();
    }

    /**
     * Will make an API call to update the post
     * @param postId
     * @param title
     * @param text content for the post
     */
    updatePost(postId, title, text) {
        this.props.actions.updatePost(postId, title, text);
        this.setState({
            editMode: false
        });
    }

    /**
     * Render DOM for Main /Home component
     */
    render() {
        //get list of posts
        let blogsList = (this.props.posts) ? this.props.posts.list : [];
        //get selected post if one exists
        let selectedBlog = (this.props.posts) ? this.props.posts[this.state.postId] : null;
        //get if post is opened in edit mode
        let editMode = this.state.editMode;
        //get if request is to create new post
        let createMode = this.state.createMode;
        return (
            <main className={"col-md-12 blog-page"}>
                <aside className="col-md-2 post-list">
                    <PostsList posts={blogsList}
                               showBlog={this.showBlog}
                               showCreateView={this.showCreateView}
                               clearAllPosts={this.clearAllPosts}
                    />
                </aside>
                    <article className="col-md-10 post">
                        {(!createMode && selectedBlog) && <div>
                            <p className="blog-title">{selectedBlog.title}
                                <time>{selectedBlog.timestamp}</time>
                                <a onClick={this.enableEditMode}>{i18n.post.editLabel}</a>
                                <a onClick={this.deletePost}>{i18n.post.deleteLabel}</a>
                            </p>
                            {(editMode)? <PostEdit
                                updatePost={this.updatePost}
                                postId={selectedBlog.id}
                                title={selectedBlog.title}
                                text={selectedBlog.text}/> : <PostView text={selectedBlog.text}/>}
                        </div>}
                        {(createMode) && <NewPost createNewPost={this.createNewPost}/>}
                    </article>
            </main>
        );
    }
}

/**
 * Home Page required and optional props
 */
HomePage.propTypes = {
    actions: PropTypes.object.isRequired,
    httpStatus: PropTypes.object.isRequired,
    posts: PropTypes.object,
    errorMessage: PropTypes.string,
    ajaxCallInProgress: PropTypes.bool
};

/**
 * Map state to props coming from action
 * @param state
 */
function mapStateToProps(state) {
    return {
        errorMessage: state.httpStatus.errorMessage,
        ajaxCallInProgress: state.httpStatus.ajaxCallInProgress,
        posts: state.blogs.list
    };
}

/**
 * Will connect the component to API actions
 * @param dispatch
 */
function mapDispatchToProps(dispatch) {
    return {
        httpStatus: bindActionCreators(httpStatus, dispatch),
        actions : bindActionCreators(gitUsersAction, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps) (HomePage);