SalesForce Assignment (Prasad Ubhalkar)

* Install Node Modules
    * Run npm install / yarn
    * To start the server run npm start
    * To run dev server might have to enable CORS plugin in Chrome
* Issues
    * There is a command integrated to create Prod release
        npm run build:prod
      This command will create distribution folder to be dumped
      under the webapp for ui blog (which does not work for me)
    * I tried to dump it under the app folder under the ui-blog
      but does not seem to be pulling up the data, not sure why
* Features
    * React Redux Component
    * Normalized Blog data
    * Internationalization
    * Accessibility
    * Bootstrap Grid Integration 